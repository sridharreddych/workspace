package com.developersBook.springExample.service;

import com.developersBook.springExample.domain.Name;

public interface ByeService {
	public String sayBye(Name name);
}
