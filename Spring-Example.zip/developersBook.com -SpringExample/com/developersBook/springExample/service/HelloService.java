package com.developersBook.springExample.service;

import com.developersBook.springExample.domain.Name;

public interface HelloService {
	public String sayHello(Name name);
}
